HDFView with hdf-java version 2.11.0
------------------------------------------------------------------------------

This directory contains the binary (release) distribution of 
HDFView 2.11 that was compiled on;
    Windows 7 x64, using VISUAL STUDIO 2012 / Java 1.7. An embedded JRE will be installed.. 

It was built with the following options: 
    -- STATIC HDF 
    -- STATIC HDF5 

The contents of this directory are:

    COPYING                 - Copyright notice
    README.txt              - This file
    HDFView-2.11.0-win64.exe  - HDFJAVA Install Package

Installation
===========================================================================
1. Execute HDFView-2.11.0-win64.exe
2. Follow prompts
===========================================================================

After Installation
===========================================================================
The compressed examples file HDFJavaExamples-0.1.1-Source.zip, located in the 
HDFView install folder, can be built and tested with CMake and the supplied
HDFJAVA_Examples.cmake file. The HDFJAVA_Examples.cmake expects HDFView with hdf-java 
to have been installed in the default location with JAVA 1.7 installed.
Also, CMake and 7Zip utilities should be installed.

To test the installation with the examples;
    Create a directory to run the examples.
    Copy HDFJavaExamples-0.1.1-Source.zip to this directory, do NOT unzip.
    Copy HDFJAVA_Examples.cmake to this directory.
    Edit HDFJAVA_Examples.cmake line 8 to set INSTALLDIR to where HDFView is installed.
    Execute from this directory: 
        ctest -S HDFJAVA_Examples.cmake,HDFJavaExamples-0.1.1-Source -C Release -V -O test.log

When executed, the ctest script will save the results to the log file, test.log, as
indicated by the ctest command. If you wish the to see more build and test information, 
add "-VV" to the ctest command. The output should show;
      100% tests passed, 0 tests failed out of 48.

For more information see USING_CMake_Examples.txt in the install folder. 
===========================================================================

Documentation for this release can be found at the following URL:
    http://www.hdfgroup.org/products/java/hdf-java-html/hdfview/.

See the HDF-JAVA home page for further details:
    http://hdfgroup.org/products/java/hdf-java-html/

Bugs should be reported to help@hdfgroup.org.
